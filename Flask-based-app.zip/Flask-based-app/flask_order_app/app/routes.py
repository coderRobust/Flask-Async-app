from flask import Blueprint, request, jsonify
from app.models import save_order

order_blueprint = Blueprint("orders", __name__)

@order_blueprint.route("/order", methods=["POST"])
def place_order():
    data = request.get_json()
    if not data or "order_id" not in data:
        return jsonify({"error": "Invalid order data"}), 400

    save_order(data)  # Save order using the batch queue
    return jsonify({"message": "Order placed successfully"}), 201