import json
import logging
import threading
import time
from tinydb import TinyDB
from tinydb.storages import JSONStorage
from tinydb.middlewares import CachingMiddleware

# Configure Logging
log_file = "logs/app.log"
logging.basicConfig(
    filename=log_file,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)
logging.info("🔄 TinyDB Batch Write System Initialized")

# Initialize Database & Order Queue
db = TinyDB("orders.json", storage=CachingMiddleware(JSONStorage))  # Cache to reduce I/O
orders_table = db.table("_default")  # Ensure orders are stored in _default
order_queue = []
batch_size = 10  # Adjust batch size based on load

# Create a lock to prevent concurrent writes
db_lock = threading.Lock()

def batch_save():
    """Saves queued orders to TinyDB in batch every second."""
    while True:
        time.sleep(1)  # Wait before writing to disk

        if order_queue:
            with db_lock:  # Lock database writes
                try:
                    # Write to TinyDB in batch
                    orders_table.insert_multiple(order_queue.copy())

                    # Log success
                    logging.info(f"✅ {len(order_queue)} orders saved successfully.")

                    # Write TinyDB content as valid JSON
                    with open("orders.json", "w") as f:
                        json.dump({"_default": orders_table.all()}, f, indent=4)

                    order_queue.clear()  # Clear queue after writing

                except json.JSONDecodeError:
                    logging.error("⚠️ JSONDecodeError: Corrupt orders.json detected. Resetting...")
                    with open("orders.json", "w") as f:
                        json.dump({"_default": []}, f, indent=4)  # Reset file

                except Exception as e:
                    logging.error(f"🔥 Error saving orders: {e}")

# Start Background Batch Save Thread
threading.Thread(target=batch_save, daemon=True).start()

def save_order(order):
    """Adds an order to the queue instead of writing immediately."""
    try:
        with db_lock:  # Ensure order queue modifications are thread-safe
            order_queue.append(order)
            logging.info(f"📝 Order received: {order}")

    except Exception as e:
        logging.error(f"❌ Failed to queue order: {order}, Error: {e}")