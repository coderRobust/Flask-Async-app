from flask import Flask
from app.routes import order_blueprint

def create_app():
    app = Flask(__name__)
    app.register_blueprint(order_blueprint)  # Register routes
    return app