workers = 8  # Increase the number of worker processes
threads = 4  # Use multi-threading to process more requests
worker_class = "gevent"  # Use Gevent for asynchronous handling
bind = "0.0.0.0:5000"
timeout = 120