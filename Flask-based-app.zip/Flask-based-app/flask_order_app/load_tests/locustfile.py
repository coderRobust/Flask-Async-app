from locust import HttpUser, task, between

class OrderTest(HttpUser):
    wait_time = between(0.01, 0.02)

    def on_start(self):
        """Ensure Locust uses HTTP instead of HTTPS"""
        self.client.base_url = "http://nginx"  # Ensure this is HTTP, NOT HTTPS

    @task
    def place_order(self):
        self.client.post("/order", json={"order_id": "12345", "item": "Pizza", "quantity": 2})